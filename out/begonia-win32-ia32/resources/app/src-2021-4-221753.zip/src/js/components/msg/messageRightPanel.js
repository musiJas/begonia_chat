// main page 右边位置
import  React  from 'react'
import { connect } from 'react-redux'
import {MessageState}  from  '../../common/constants' 

import {sendMsg} from '../../utils/https'

import {uuid} from '../../utils/uuid'

type props={
    route: RouteT,
    dispatch: Dispatch,
}


class  MessageRightPanel extends  React.Component<props,MessageState>{
    constructor(props) {
        super(props)
        this.state = {
            showScroll: false,
            msg:''
        }
      }

 

    btn_sendMsg(props){
        // private  String  reqId; //请求ID
        // private  String  groupId; //组id
        // private  String  from; //从哪里来
        // private  String  to;  // 去哪里
        // private  Object  msg; // 发送的消息
        // private  String    gmtTime; //发送的时间
        console.log(this.state);
        console.log(this.props);

        let requestMsg={
            reqId:uuid(),
            groupId:'',
            from:this.props.route.from,
            to:this.props.route.to,
            msg:this.state.msg,
            gmtTime:new Date().toGMTString()
        }
        console.log(requestMsg);
        let res=sendMsg(requestMsg); 
        if(res.code=200){
            //**清空数据 写入列表 */
            this.setState({
                msg:''
            })
        }else {
            console.log(res.msg);
        }
    }  
 



    renderContents() {
        
        const { route } = this.props

        console.log(this.state); 
        
        switch (route.type) { 
            case 'DEFAULTMESSAGE_ONLINE':
                return <DefaultMainPage />
            case 'PRECHECKMESSAGE_ONLINE':
                return <MainPage state={this.state}   route={route} 
                        onMouseEnter={(props,e) => {
                            this.setState({
                                showScroll:props.showScroll
                            })
                        }}
                        onMouseLeave={(props) => {
                            this.setState({
                                showScroll:props.showScroll
                            })
                        }}
                        // onClick={this.btn_sendMsg.bind(this)}
                        onSubmit={()=>{
                            this.btn_sendMsg(this.props)                            
                            //console.log('12312')
                            } 
                        }
                        onChange={(props)=>{
                            this.setState({
                                msg:props.msg
                            })
                        }}
                        />
            default:
                return <DefaultMainPage />

        }
    }


    render() {
        const { route, connections, children, dispatch } = this.props
            return (
                <React.Fragment>
                    {this.renderContents()}
                </React.Fragment>
            )
        }
}

const DefaultMainPage=(props) => (
    <div className="main_defaultPage" >
        <span className="main_defaultSpan">welcome.default page  </span>
    </div>
  )
  

const  MainPage=(prop)=>(
    <React.Fragment>
        <MainTop state={prop.state}  route={prop.route} onMouseEnter={(props) => { 
                        prop.onMouseEnter(props)
                        // e.stopPropagation()
                    }}  
                    onMouseLeave={(props) => {
                        prop.onMouseLeave(props)
                        // e.stopPropagation()
                    }} />
        <MainButtom  state={prop.state}      
            onChange={(props)=>{
                prop.onChange(props)
            }}
            onSubmit={prop.onSubmit}
            />
    </React.Fragment>
)

const  MainTop=(props)=>(
    <div className='message_main'>
        <div className='message_top'>
                <span>{props.route.userName}</span>
                <span className='message_topRight'>...</span>
        </div> 
        <hr className='message_hr'/>
        <div className={`message-main-top ${props.state.showScroll?"show_scroll":'' }`}   
            onMouseEnter={(e)=>{
                    props.onMouseEnter({
                        showScroll:true
                    })
                    e.stopPropagation()
                }} 
            onMouseLeave={(e)=>{
                props.onMouseLeave({
                    showScroll:false
                })
                e.stopPropagation()
            }} >
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>
                <li>hello world!!!</li>

        </div>
        <hr className='message_hr_top'/>
    </div>
)
const  MainButtom=(props)=>(
    <div className="message-main-buttom">
        <div className='message_btn_group'>
            <button className='message_btn'>
                bt1
            </button>
            <button>
                bt1
            </button>
        </div>

        <div>
            {/* <input className='message_input'></input> */}
            <textarea  value={props.state.msg}
            onChange={(e)=>{
                props.onChange({
                    msg:e.target.value
                })
                e.stopPropagation()
            }} 
            className='message_textarea'>

            </textarea>
        </div>
        <div className='message_buttom_btn'>
            <button className='message_buttom_btn_inner'
                onClick={props.onSubmit} 
                >
                send
            </button>
        </div>
    </div>
)

export default connect((state: MessageState, ownProps): $Shape<Props> => {
    return {
      route: state.messageModule
    }
  })(MessageRightPanel)